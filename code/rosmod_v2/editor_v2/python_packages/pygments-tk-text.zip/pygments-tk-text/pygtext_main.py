from Tkinter import Tk
from pygments.lexers import HtmlLexer, PythonLexer
from tkformatter  import TkFormatter
from pygtext import PygmentsText
from tidylib import tidy_fragment, tidy_document

# Example main program. Constructs a simple Tk Text window, then loads
# syntax-colored code into it.

root = Tk()
root.attributes('-topmost', 1)  # for convenience, pops window to the top

format = "python"

if format == "html":
    html = '<html><head><title>lsdfkjs</title></head><body lang="en"><p id="44">sldfjsd&mdash;jsfldj</body></html>'
    tidyhtml, errors = tidy_document(html)
    ptext = PygmentsText(root, HtmlLexer(), TkFormatter(style='tango'))
    ptext.insertFormatted("end", tidyhtml)
    
elif format == "python":
    py = open('pygtext_main.py').read()
    ptext = PygmentsText(root, PythonLexer(), TkFormatter())
    ptext.insertFormatted("end", py)

ptext.pack()
root.mainloop()
