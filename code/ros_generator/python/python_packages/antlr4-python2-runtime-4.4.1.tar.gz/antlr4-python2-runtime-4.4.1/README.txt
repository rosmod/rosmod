This is the Python 2.7 runtime for AntLR.
Visit the AntLR web site for more information:
http://www.antlr.org